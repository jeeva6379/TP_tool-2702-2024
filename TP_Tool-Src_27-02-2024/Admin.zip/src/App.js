// import React from 'react';

// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import LoginForm from './LoginForm';
// import Dashboard from './Component/Dashboard';
// import Createnewuser from './Component/Createnewuser';
// const App = () => {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<LoginForm />} />
//         <Route path="/Dashboard" element={<Dashboard />} />
//         <Route path="/Createnewuser" element={<Createnewuser />} />

// =      </Routes>
//     </Router>
//   );
// };

// export default App;
