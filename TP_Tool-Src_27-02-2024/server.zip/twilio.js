require("dotenv").config();
const twilio = require("twilio");

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;

const sendSms = (phone, message) => {
  const client = twilio(accountSid, authToken);
  client.messages
    .create({
      body: message,
      from:process.env.TWILIO_PHONE_NUMBER,
      to: phone, 
    })
    .then((message) => console.log(message.sid))
    .catch((error) => console.error(error));
};

module.exports = sendSms;
// recovery id
// TVCVJ2W5VT41A2UGRRGLPAD3